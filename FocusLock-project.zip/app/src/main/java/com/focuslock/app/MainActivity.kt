@file:OptIn(ExperimentalFoundationApi::class)

package com.focuslock.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.focuslock.app.data.AppInfo
import com.focuslock.app.data.MainViewModel
import com.focuslock.app.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class FocusLockApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "focuslock", "FocusLock", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

fun isAccessibilityServiceEnabled(context: android.content.Context): Boolean {
    val expected = "${context.packageName}/${BlockingService::class.java.canonicalName}"
    val enabled = Settings.Secure.getString(
        context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val splitter = TextUtils.SimpleStringSplitter(':')
    splitter.setString(enabled)
    while (splitter.hasNext()) {
        if (splitter.next().equals(expected, ignoreCase = true)) return true
    }
    return false
}

fun hasOverlayPermission(context: android.content.Context): Boolean =
    Settings.canDrawOverlays(context)

fun hasBatteryOptimizationExemption(context: android.content.Context): Boolean {
    val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FocusLockTheme {
                val isBlocking by viewModel.isBlocking.collectAsState()
                val endTime by viewModel.endTime.collectAsState()
                val pagerState = rememberPagerState(pageCount = { AppTab.values().size })
                val scope = rememberCoroutineScope()
                val haptics = LocalHapticFeedback.current
                val context = LocalContext.current

                // Разрешения проверяются один раз, здесь, на самом верху — а не
                // внутри вкладки "Домой". Пока хоть одно не выдано, вместо вкладок
                // показывается мастер настройки: это гарантирует, что к моменту,
                // когда пользователь вообще видит список приложений и кнопку
                // "Начать блокировку", служба уже способна реально заблокировать
                // экран, а не просто запустить таймер вхолостую.
                var accessibilityGranted by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }
                var overlayGranted by remember { mutableStateOf(hasOverlayPermission(context)) }
                var batteryOptGranted by remember { mutableStateOf(hasBatteryOptimizationExemption(context)) }
                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            accessibilityGranted = isAccessibilityServiceEnabled(context)
                            overlayGranted = hasOverlayPermission(context)
                            batteryOptGranted = hasBatteryOptimizationExemption(context)
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                }
                val setupComplete = accessibilityGranted && overlayGranted && batteryOptGranted

                // Лёгкий тактильный отклик при смене вкладки — срабатывает и от
                // нажатия на нижнюю панель, и от свайпа, потому что оба способа
                // в итоге меняют pagerState.settledPage.
                var previousSettledPage by remember { mutableStateOf(pagerState.settledPage) }
                LaunchedEffect(pagerState.settledPage) {
                    if (pagerState.settledPage != previousSettledPage) {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        previousSettledPage = pagerState.settledPage
                    }
                }

                val screen = when {
                    isBlocking -> RootScreen.Blocking
                    !setupComplete -> RootScreen.Wizard
                    else -> RootScreen.Main
                }

                Surface(modifier = Modifier.fillMaxSize(), color = DeepBlack) {
                    Crossfade(targetState = screen, label = "nav") { s ->
                        when (s) {
                            RootScreen.Blocking -> ActiveBlockScreen(endTime = endTime, onExpired = { viewModel.stopBlocking() })
                            RootScreen.Wizard -> PermissionWizardScreen(
                                accessibilityGranted = accessibilityGranted,
                                overlayGranted = overlayGranted,
                                batteryOptGranted = batteryOptGranted
                            )
                            RootScreen.Main -> {
                                // Вкладки доступны только вне активной блокировки — во время
                                // фокус-сессии экран нарочно "одноцелевой", без навигации.
                                Scaffold(
                                    containerColor = Color.Transparent,
                                    bottomBar = {
                                        FocusLockBottomBar(
                                            currentTab = AppTab.values()[pagerState.currentPage],
                                            onTabSelected = { tab ->
                                                scope.launch { pagerState.animateScrollToPage(tab.ordinal) }
                                            }
                                        )
                                    }
                                ) { innerPadding ->
                                    // Свайп между вкладками (Блокировка ←→ Расписания ←→
                                    // Статистика), как в Telegram. Нижняя навигация выше не
                                    // ломается — она просто просит pager анимированно
                                    // перейти на нужную страницу.
                                    HorizontalPager(
                                        state = pagerState,
                                        modifier = Modifier.fillMaxSize().padding(innerPadding)
                                    ) { page ->
                                        when (AppTab.values()[page]) {
                                            AppTab.Home -> MainScreen(viewModel = viewModel)
                                            AppTab.Schedules -> SchedulesScreen(viewModel = viewModel)
                                            AppTab.Stats -> StatsScreen(viewModel = viewModel)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

enum class RootScreen { Blocking, Wizard, Main }

enum class AppTab { Home, Schedules, Stats }

@Composable
fun FocusLockBottomBar(currentTab: AppTab, onTabSelected: (AppTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .glassCard(20)
            .padding(vertical = 8.dp, horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        BottomBarItem(
            icon = Icons.Default.Lock,
            label = "Блокировка",
            selected = currentTab == AppTab.Home,
            onClick = { onTabSelected(AppTab.Home) },
            modifier = Modifier.weight(1f)
        )
        BottomBarItem(
            icon = Icons.Default.DateRange,
            label = "Расписания",
            selected = currentTab == AppTab.Schedules,
            onClick = { onTabSelected(AppTab.Schedules) },
            modifier = Modifier.weight(1f)
        )
        BottomBarItem(
            icon = Icons.Default.BarChart,
            label = "Статистика",
            selected = currentTab == AppTab.Stats,
            onClick = { onTabSelected(AppTab.Stats) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun BottomBarItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp)
    ) {
        Icon(icon, null, tint = if (selected) Cyan else TextSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            color = if (selected) Cyan else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val apps by viewModel.installedApps.collectAsState()
    val selected by viewModel.selectedPackages.collectAsState()
    var search by remember { mutableStateOf("") }
    var durationMinutes by remember { mutableStateOf(30) }
    var durationText by remember { mutableStateOf("30") }
    var countdown by remember { mutableStateOf<Int?>(null) }
    val listState = rememberLazyListState()
    val haptics = LocalHapticFeedback.current

    // Задача 4.2: список "раскрывается" (карточка длительности сжимается,
    // освобождая место), когда пользователь либо начал прокручивать список,
    // либо закончил набирать текст (ушёл из поля — клавиатура, скорее всего,
    // скрылась). "Липкое" состояние: один раз раскрывшись, обратно не
    // схлопывается — иначе элементы дёргались бы туда-сюда при прокрутке
    // вверх-вниз у самого начала списка.
    var listExpanded by remember { mutableStateOf(false) }
    var searchWasFocused by remember { mutableStateOf(false) }
    var durationWasFocused by remember { mutableStateOf(false) }
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 0 }
            .collect { scrolled -> if (scrolled) listExpanded = true }
    }

    val filtered = remember(apps, search) {
        if (search.isBlank()) apps else apps.filter { it.label.contains(search, ignoreCase = true) }
    }

    LaunchedEffect(countdown) {
        val c = countdown ?: return@LaunchedEffect
        if (c > 0) {
            delay(1000)
            countdown = c - 1
        } else {
            // Оверлей блокировки запускает исключительно BlockingService, когда
            // видит открытие заблокированного приложения — здесь мы только
            // включаем режим блокировки в хранилище.
            viewModel.startBlocking(durationMinutes * 60_000L)
            countdown = null
        }
    }

    OrganicBackground {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Text(
                "FocusLock",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Заблокируй отвлечения и сфокусируйся",
                color = TextSecondary,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            // Время блокировки — свой ввод + быстрые пресеты. Ряд пресетов
            // сворачивается, когда список "раскрыт" (см. listExpanded выше) —
            // освобождает немного места для списка приложений, но сам степпер
            // остаётся всегда доступным.
            Column(
                modifier = Modifier.fillMaxWidth().glassCard(16).padding(16.dp).animateContentSize()
            ) {
                Text("Время блокировки", color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        val v = (durationMinutes - 5).coerceAtLeast(1)
                        durationMinutes = v; durationText = v.toString()
                    }) { Icon(Icons.Default.Remove, null, tint = Cyan) }

                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { new ->
                            val digits = new.filter { it.isDigit() }.take(4)
                            durationText = digits
                            digits.toIntOrNull()?.let { if (it in 1..999) durationMinutes = it }
                        },
                        modifier = Modifier.width(110.dp).onFocusChanged { state ->
                            if (state.isFocused) durationWasFocused = true
                            else if (durationWasFocused) listExpanded = true
                        },
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        ),
                        suffix = { Text("мин", color = TextSecondary, fontSize = 13.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.3f),
                            cursorColor = Cyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    IconButton(onClick = {
                        val v = (durationMinutes + 5).coerceAtMost(999)
                        durationMinutes = v; durationText = v.toString()
                    }) { Icon(Icons.Default.Add, null, tint = Cyan) }
                }
                if (!listExpanded) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(15, 30, 60, 120).forEach { m ->
                            DurationChip(m, m == durationMinutes) { durationMinutes = m; durationText = m.toString() }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Поиск приложений", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = TextSecondary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().onFocusChanged { state ->
                    if (state.isFocused) searchWasFocused = true
                    else if (searchWasFocused) listExpanded = true
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = TextSecondary.copy(alpha = 0.3f),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Cyan
                ),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Выбрано: ${selected.size}", color = TextSecondary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.selectAll()
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Выбрать всё", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(
                        onClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            viewModel.deselectAll()
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Снять всё", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Список приложений + "ползунок" быстрой прокрутки рядом с ним (листать
            // вручную десятки приложений неудобно — ползунком можно перейти сразу
            // к нужной букве). Раньше кнопка "Начать блокировку" была отдельным
            // элементом, наложенным поверх этой колонки через Box+align(BottomCenter),
            // из-за чего при появлении карточки разрешений список мог визуально
            // налезать на кнопку. Теперь кнопка — обычный последний элемент этой же
            // Column, а список (с весом 1f) сам подстраивает высоту под неё, так что
            // наложения быть не может ни при каком состоянии разрешений.
            Row(modifier = Modifier.weight(1f)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fadingEdges(listState),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered, key = { it.packageName }) { app ->
                        AppRow(app, app.packageName in selected) { viewModel.toggleApp(app.packageName) }
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }
                if (filtered.size > 14) {
                    FastScrollbar(
                        listState = listState,
                        itemCount = filtered.size,
                        modifier = Modifier.fillMaxHeight(),
                        labelForIndex = { idx -> filtered.getOrNull(idx)?.label?.firstOrNull()?.uppercase() }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            val pulse = rememberInfiniteTransition(label = "pulse")
            val scale by pulse.animateFloat(
                initialValue = 1f, targetValue = 1.04f,
                animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale"
            )

            Button(
                onClick = {
                    if (selected.isEmpty() || durationMinutes <= 0) return@Button
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    countdown = 3
                },
                enabled = selected.isNotEmpty() && durationMinutes > 0 && countdown == null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .graphicsLayerScale(scale),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Lock, null)
                Spacer(Modifier.width(8.dp))
                Text("Начать блокировку", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        countdown?.let { c ->
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AnimatedContent(targetState = c, label = "countdown") { value ->
                        Text(
                            text = if (value > 0) "$value" else "🔒",
                            color = Cyan,
                            fontSize = 96.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(28.dp))
                    TextButton(onClick = { countdown = null }) {
                        Text("Отмена", color = TextSecondary, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

fun Modifier.graphicsLayerScale(scale: Float): Modifier = this.then(
    Modifier.graphicsLayer(scaleX = scale, scaleY = scale)
)

@Composable
fun DurationChip(minutes: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) Cyan else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) Cyan else TextSecondary.copy(alpha = 0.4f),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            "$minutes",
            color = if (selected) Color.Black else TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun AppRow(app: AppInfo, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(14)
            .clickable { onToggle() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        app.icon?.let { drawable ->
            Image(
                bitmap = drawable.toBitmap(96, 96).asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
            )
        } ?: Box(modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(CyanDim))
        Spacer(Modifier.width(12.dp))
        Text(app.label, color = TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Checkbox(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = Cyan, uncheckedColor = TextSecondary)
        )
    }
}

@Composable
fun ActiveBlockScreen(endTime: Long, onExpired: () -> Unit) {
    var remaining by remember { mutableStateOf(((endTime - System.currentTimeMillis()) / 1000).coerceAtLeast(0)) }

    LaunchedEffect(endTime) {
        while (remaining > 0) {
            delay(1000)
            remaining = ((endTime - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        }
        // Таймер дошёл до нуля прямо в приложении — снимаем блокировку сами,
        // не полагаясь на то, что оверлей когда-либо успел сработать.
        onExpired()
    }

    BackHandler(enabled = true) { /* блокировка активна — назад не работает */ }

    OrganicBackground(contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            GlassIconBadge(Icons.Default.Lock, sizeDp = 84)
            Spacer(Modifier.height(20.dp))
            Text("Фокус активен", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            val h = remaining / 3600
            val m = (remaining % 3600) / 60
            val s = remaining % 60
            Text(
                String.format("%02d:%02d:%02d", h, m, s),
                color = Cyan,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Заблокированные приложения недоступны до конца таймера",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )
        }
    }
}
