package com.focuslock.app

import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.focuslock.app.data.LockRepository
import com.focuslock.app.ui.Cyan
import com.focuslock.app.ui.CyanDim
import com.focuslock.app.ui.DeepBlack
import com.focuslock.app.ui.TextSecondary
import com.focuslock.app.ui.OrganicBackground
import com.focuslock.app.ui.GlassIconBadge
import com.focuslock.app.ui.glassCard
import kotlinx.coroutines.delay

/** Минимальный владелец жизненного цикла для ComposeView вне Activity */
private class OverlayLifecycleOwner :
    LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore = ViewModelStore()
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    fun handleLifecycleEvent(event: Lifecycle.Event) {
        lifecycleRegistry.handleLifecycleEvent(event)
    }

    fun performRestore() {
        savedStateController.performRestore(null)
    }
}

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlayView == null) showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        LockRepository.writeDebugEvent(this, "showOverlay() запущен")
        val effective = LockRepository.readEffectiveBlockState(this)
        if (!effective.active) {
            LockRepository.writeDebugEvent(this, "showOverlay: блокировка уже не активна")
            stopSelf()
            return
        }
        if (!LockRepository.isCurrentlyOnBlockedApp(this)) {
            // Пользователь уже успел уйти из заблокированного приложения раньше,
            // чем сервис запустился (например, быстрое переключение) — не
            // показываем оверлей поверх того, что сейчас на самом деле открыто.
            LockRepository.writeDebugEvent(this, "showOverlay: приложение уже не заблокировано")
            stopSelf()
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            // Без этого разрешения окно не может быть добавлено — сообщаем и выходим,
            // вместо того чтобы тихо ничего не делать.
            LockRepository.writeDebugEvent(this, "НЕТ прав на оверлей (canDrawOverlays=false)")
            Toast.makeText(
                this,
                "FocusLock: разрешите «Отображение поверх других приложений», иначе блокировка не сработает",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
            return
        }

        val owner = OverlayLifecycleOwner()
        owner.performRestore()
        owner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        owner.handleLifecycleEvent(Lifecycle.Event.ON_START)
        owner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        lifecycleOwner = owner

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        // Без FLAG_NOT_FOCUSABLE и FLAG_NOT_TOUCH_MODAL: оверлей перехватывает
        // все касания и клавиши (в т.ч. Back), не пропуская их дальше.
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        // ComposeView — финальный класс, его нельзя наследовать напрямую.
        // Оборачиваем в FrameLayout и перехватываем Back уже на нём.
        val composeView = ComposeView(this).apply {
            setContent {
                OverlayContent(
                    startTime = effective.segmentStart,
                    endTime = effective.segmentEnd,
                    onExpired = {
                        LockRepository.clearBlockingState(this@OverlayService)
                        stopSelf()
                    }
                )
            }
        }

        // Владельца жизненного цикла нужно вешать на КОРНЕВОЙ view окна (rootView),
        // а не на дочерний composeView: Compose при подключении окна ищет
        // ViewTreeLifecycleOwner именно у view.rootView, поэтому привязка к
        // composeView (что было раньше) приводила к падению с
        // IllegalStateException в момент отрисовки — оверлей "добавлялся",
        // но тут же крашился, так и не показавшись.
        val rootView = object : FrameLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) return true
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            addView(
                composeView,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        overlayView = rootView

        try {
            wm.addView(rootView, params)
            hideSystemBars(rootView)
            // Лёгкий тактильный отклик в момент появления экрана блокировки.
            // Не Compose-дерево (это ComposeView добавляется напрямую через
            // WindowManager), поэтому используем View.performHapticFeedback, а не
            // LocalHapticFeedback — без FLAG_IGNORE_GLOBAL_SETTING, чтобы уважать
            // системную настройку "виброотклик", если пользователь её выключил.
            rootView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            LockRepository.writeDebugEvent(this, "Оверлей добавлен успешно")
        } catch (e: Exception) {
            LockRepository.writeDebugEvent(this, "Ошибка addView: ${e.javaClass.simpleName}: ${e.message}")
            stopSelf()
        }
    }

    // Полноэкранный режим (скрывает статус-бар и нижнюю системную панель).
    // Это только про видимость системных панелей — на перехват кнопки/жеста
    // "Назад" (dispatchKeyEvent на rootView выше) никак не влияет, он
    // продолжает работать как раньше.
    private fun hideSystemBars(view: View) {
        val controller = androidx.core.view.ViewCompat.getWindowInsetsController(view) ?: return
        controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        // Самовосстановление нужно ТОЛЬКО если пользователь по-прежнему на
        // заблокированном приложении (например, систему убила службу в фоне).
        // Раньше здесь проверялся только общий таймер сессии (isBlocking),
        // из-за чего оверлей поднимался заново даже после ухода на Home —
        // и блокировка не отпускала пользователя до конца всего таймера.
        val effective = LockRepository.readEffectiveBlockState(this)
        val stillOnBlockedApp = LockRepository.isCurrentlyOnBlockedApp(this)
        if (effective.active && stillOnBlockedApp) {
            val restart = Intent(this, OverlayService::class.java)
            startForegroundService(restart)
        }
    }

    private fun removeOverlay() {
        overlayView?.let { view ->
            try { windowManager?.removeView(view) } catch (e: Exception) {}
        }
        lifecycleOwner?.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        overlayView = null
        lifecycleOwner = null
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel("focuslock") == null) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(
                        "focuslock", "FocusLock", NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
        }
        val notification = NotificationCompat.Builder(this, "focuslock")
            .setContentTitle("FocusLock: блокировка активна")
            .setContentText("Заблокированные приложения недоступны")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setSilent(true)
            .build()
        startForeground(1002, notification)
    }
}

@Composable
fun OverlayContent(startTime: Long, endTime: Long, onExpired: () -> Unit) {
    var remaining by remember { mutableStateOf(((endTime - System.currentTimeMillis()) / 1000).coerceAtLeast(0)) }
    // Длительность ВСЕЙ текущей сессии блокировки (от startTime до endTime), а
    // НЕ время, оставшееся на момент открытия экрана. Раньше totalDuration
    // считался как remember { оставшееся_время_сейчас }, поэтому при каждом
    // открытии заблокированного приложения индикатор считал, будто сессия
    // только что началась — даже если она уже шла долгое время.
    val totalDurationSec = remember(startTime, endTime) { ((endTime - startTime) / 1000).coerceAtLeast(1) }

    LaunchedEffect(endTime) {
        while (true) {
            val left = ((endTime - System.currentTimeMillis()) / 1000)
            remaining = left.coerceAtLeast(0)
            if (left <= 0) {
                onExpired()
                break
            }
            delay(1000)
        }
    }

    // Круг заполняется по мере прохождения ВСЕЙ сессии и становится полным
    // ровно к её концу — не зависит от того, в какой момент пользователь
    // открыл заблокированное приложение и увидел этот экран.
    val elapsedSec = (totalDurationSec - remaining).coerceIn(0L, totalDurationSec)
    val targetProgress = (elapsedSec.toFloat() / totalDurationSec.toFloat()).coerceIn(0f, 1f)
    // remaining меняется раз в секунду, поэтому дуга раньше "прыгала".
    // Анимируем переход между значениями линейно за то же время (1с) —
    // визуально дуга крутится плавно, а не скачками.
    val progress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 1000, easing = LinearEasing),
        label = "progress"
    )
    val infinite = rememberInfiniteTransition(label = "glow")
    val glow by infinite.animateFloat(
        initialValue = 0.6f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "glowAlpha"
    )

    Surface(modifier = Modifier.fillMaxSize(), color = DeepBlack) {
        OrganicBackground(contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.glassCard(32).padding(horizontal = 40.dp, vertical = 36.dp)
            ) {
                GlassIconBadge(Icons.Default.Lock, sizeDp = 58)
                Spacer(Modifier.height(22.dp))
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
                    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 12.dp.toPx()
                        drawArc(
                            color = CyanDim.copy(alpha = 0.22f),
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = stroke)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(listOf(Cyan, CyanDim, Cyan)),
                            startAngle = -90f,
                            sweepAngle = 360f * progress,
                            useCenter = false,
                            style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        )
                    }
                    val h = remaining / 3600
                    val m = (remaining % 3600) / 60
                    val s = remaining % 60
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format("%02d:%02d:%02d", h, m, s),
                            color = Cyan.copy(alpha = glow),
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Заблокировано",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Глубокий вдох. Фокус того стоит",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val (isBlocking, endTime, _) = LockRepository.readBlockingState(context)
        if (isBlocking && System.currentTimeMillis() < endTime) {
            val serviceIntent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else if (isBlocking) {
            LockRepository.clearBlockingState(context)
        }
    }
}
